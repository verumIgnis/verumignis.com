/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_hid.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
extern USBD_HandleTypeDef hUsbDeviceFS;

#define HID_KEY_A 0x04

#define MAX_HELD_KEYS 5

#define FLASH_SCRIPT_START 0x08004000U  // upper 16 KB start
#define FLASH_SCRIPT_SIZE  (16*1024)


typedef struct {
  uint8_t modifier;            // Ctrl, Shift, Alt, etc.
  uint8_t reserved;   	   	   // Reserved byte
  uint8_t keycode[6]; 		   // Up to 6 keys pressed simultaneously
} KeyboardHID_t;

KeyboardHID_t keyboardHID = {0};

uint16_t speed = 20; 		   // default typing speed
uint8_t heldModifier = 0;      // modifiers currently held via HOLD
uint8_t heldKeys[6] = {0};     // non-modifier keys currently held

uint8_t char_to_hid(char c, uint8_t *modifier)
{
    *modifier = 0;

    /* Letters */
    if (c >= 'a' && c <= 'z')
        return 0x04 + (c - 'a');

    if (c >= 'A' && c <= 'Z') {
        *modifier = 0x02;
        return 0x04 + (c - 'A');
    }

    /* Numbers */
    if (c >= '1' && c <= '9')
        return 0x1E + (c - '1');

    if (c == '0')
        return 0x27;

    switch (c)
    {
        /* Control */
        case '\n': return 0x28; // Enter
        case '\b': return 0x2A; // Backspace
        case '\t': return 0x2B; // Tab
        case ' ':  return 0x2C; // Space

        /* Row: - = */
        case '-': return 0x2D;
        case '_': *modifier = 0x02; return 0x2D;

        case '=': return 0x2E;
        case '+': *modifier = 0x02; return 0x2E;

        /* Brackets */
        case '[': return 0x2F;
        case '{': *modifier = 0x02; return 0x2F;

        case ']': return 0x30;
        case '}': *modifier = 0x02; return 0x30;

        /* ISO extra key (UK \ | key near Enter) */
        case '\\': return 0x64;
        case '|':  *modifier = 0x02; return 0x64;

        /* US-style backslash position (on UK this is unused printable) */
        /* HID 0x31 is Non-US # and ~ on ISO layouts */

        /* UK # ~ key (next to Enter) */
        case '#': return 0x32;
        case '~': *modifier = 0x02; return 0x32;

        /* Semicolon / colon */
        case ';': return 0x33;
        case ':': *modifier = 0x02; return 0x33;

        /* Apostrophe / double quote */
        case '\'': return 0x34;                 // apostrophe
        case '"':  *modifier = 0x02; return 0x1F; // shift+2

        /* Grave / ¬ (UK specific) */
        case '`': return 0x35;

        /* Comma / less-than */
        case ',': return 0x36;
        case '<': *modifier = 0x02; return 0x36;

        /* Period / greater-than */
        case '.': return 0x37;
        case '>': *modifier = 0x02; return 0x37;

        /* Slash / question */
        case '/': return 0x38;
        case '?': *modifier = 0x02; return 0x38;

        /* Numbers row shifted */
        case '!': *modifier = 0x02; return 0x1E;
        case '$': *modifier = 0x02; return 0x21;
        case '%': *modifier = 0x02; return 0x22;
        case '^': *modifier = 0x02; return 0x23;
        case '&': *modifier = 0x02; return 0x24;
        case '*': *modifier = 0x02; return 0x25;
        case '(': *modifier = 0x02; return 0x26;
        case ')': *modifier = 0x02; return 0x27;
    }

    return 0; // Unsupported
}

void SendKeyWithModifier(uint8_t key, uint8_t modifier)
{
    keyboardHID.modifier = modifier | heldModifier;

    // Insert key into first free slot, probably didnt need to implement this...
    uint8_t slot = 0;
    while (slot < 6 && keyboardHID.keycode[slot] != 0) slot++;
    if (slot < 6) keyboardHID.keycode[slot] = key;

    // Send report
    USBD_HID_SendReport(&hUsbDeviceFS, (uint8_t*)&keyboardHID, sizeof(KeyboardHID_t));

    HAL_Delay(speed);

    // Release transient key
    if (slot < 6) keyboardHID.keycode[slot] = 0;
    keyboardHID.modifier = heldModifier; // keep held keys/mods

    USBD_HID_SendReport(&hUsbDeviceFS, (uint8_t*)&keyboardHID, sizeof(KeyboardHID_t));

    HAL_Delay(speed);
}

void TypeString(const char *str)
{
    while (*str)
    {
        uint8_t tmpModifier = 0;
        uint8_t key = char_to_hid(*str, &tmpModifier);

        if (key != 0)
            SendKeyWithModifier(key, tmpModifier); // only SHIFT overrides, other held mods persist

        str++;
    }
}

void RunFlashScript(void)
{
    uint8_t *ptr = (uint8_t*)FLASH_SCRIPT_START;
    uint8_t *end = ptr + FLASH_SCRIPT_SIZE;

    while (ptr < end)
    {
        uint8_t cmd = *ptr++;
        switch (cmd)
        {
            case 0x01: // SPEED
            	speed = *ptr++;         // low byte
            	speed |= (*ptr++) << 8; // high byte
                break;

            case 0x02: { // DELAY
                uint16_t delay = ptr[0] | (ptr[1] << 8);
                HAL_Delay(delay);
                ptr += 2;
                break;
            }

            case 0x03: { // HOLD
                heldModifier = *ptr++;
                for (int i = 0; i < MAX_HELD_KEYS; i++)
                    heldKeys[i] = *ptr++;
                // Update HID report immediately to reflect held keys/modifiers
                keyboardHID.modifier = heldModifier;
                memcpy(keyboardHID.keycode, heldKeys, MAX_HELD_KEYS);
                USBD_HID_SendReport(&hUsbDeviceFS, (uint8_t*)&keyboardHID, sizeof(keyboardHID));
                HAL_Delay(speed);
                break;
            }

            case 0x04: { // SINGLE MODIFIER
                uint8_t mod = *ptr++;
                SendKeyWithModifier(0, mod); // transient modifier
                break;
            }

            case 0x05: { // STRING
                uint8_t len = *ptr++;
                char buf[256];
                if (len > 255) len = 255;
                memcpy(buf, ptr, len);
                buf[len] = 0;
                TypeString(buf);
                ptr += len;
                break;
            }

            case 0x06: { // SINGLE KEY
                uint8_t key = *ptr++;
                SendKeyWithModifier(key, 0);
                break;
            }

            default:
                return;
        }
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  HAL_Delay(1000); //wait for USB to be ready
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  RunFlashScript();

  while (1)
  {
	  HAL_Delay(200);

	  /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI48;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin : PROG_Pin */
  GPIO_InitStruct.Pin = PROG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(PROG_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
